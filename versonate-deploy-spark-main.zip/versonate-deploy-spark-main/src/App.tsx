import { Routes, Route, Link } from "react-router-dom";
import Project from "./pages/Project";
import Members from "./pages/Members";
import Resources from "./pages/Resources";
import Downloads from "./pages/Downloads";
import Inspiration from "./pages/Inspiration";

function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          This page doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            Back to home
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Project />} />
      <Route path="/membres" element={<Members />} />
      <Route path="/ressources" element={<Resources />} />
      <Route path="/telechargements" element={<Downloads />} />
      <Route path="/inspiration" element={<Inspiration />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
