import { SiteLayout } from "@/components/SiteLayout";
import { ImageSlot } from "@/components/ImageSlot";
import oni from "@/assets/oni-inspiration.png";

export default function Inspiration() {
  return (
    <SiteLayout>
      <section className="container-paper pt-20 pb-12">
        <p className="mono-label mb-6">Our inspirations</p>
        <h1 className="text-3xl sm:text-5xl text-3d leading-[1.05] max-w-3xl">INSPIRATION</h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-2xl">
          Japanese folklore, mystical creatures and the blood-red aesthetics of ancient Oni legends
          shape every corner of our world.
        </p>
      </section>

      <section className="container-paper py-12 rule-top border-t border-border grid md:grid-cols-12 gap-10 items-center">
        <div className="md:col-span-6">
          <div className="rounded-xl border border-border bg-card/40 p-6 flex items-center justify-center">
            <img
              src={oni}
              alt="Oni inspiration — Japanese folklore demon"
              className="max-h-[480px] w-auto object-contain drop-shadow-[0_8px_24px_rgba(180,30,30,0.45)]"
            />
          </div>
        </div>
        <div className="md:col-span-6 space-y-5 text-lg leading-relaxed">
          <h2 className="text-2xl font-semibold">The Oni</h2>
          <p className="text-muted-foreground">
            The Oni are fearsome demons from Japanese mythology — wild, crimson-skinned, armed with
            iron clubs and untamed strength.
          </p>
          <p className="text-muted-foreground">
            Their silhouette, their colour palette and their raw presence directly inspired the
            antagonists of Onigiri.
          </p>
          <p className="text-brand-soft">
            Mystical, dark, unmistakably Japanese.
          </p>
        </div>
      </section>

      <section className="container-paper py-16 rule-top border-t border-border">
        <p className="mono-label mb-8">Mood board</p>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          <ImageSlot ratio="aspect-square" label="Inspiration 1" />
          <ImageSlot ratio="aspect-square" label="Inspiration 2" />
          <ImageSlot ratio="aspect-square" label="Inspiration 3" />
          <ImageSlot ratio="aspect-square" label="Inspiration 4" />
          <ImageSlot ratio="aspect-square" label="Inspiration 5" />
          <ImageSlot ratio="aspect-square" label="Inspiration 6" />
        </div>
      </section>
    </SiteLayout>
  );
}
