import { SiteLayout } from "@/components/SiteLayout";
import membre1 from "@/assets/membre1.jpg";
import membre2 from "@/assets/membre2.jpg";
import membre3 from "@/assets/membre3.jpg";
import membre4 from "@/assets/membre4.jpg";
import membre5 from "@/assets/membre5.jpg";


type Member = {
  firstName: string;
  lastName: string;
  role: string;
  email: string;
  photo: string;
};

const members: Member[] = [
  { firstName: "Enzo", lastName: "Bouthier", role: "Chef de projet, Network", email: "enzo.bouthier@epita.fr", photo: membre1 },
  { firstName: "Tristan", lastName: "Duret-Robert", role: "Rôle", email: "tristan.duret-robert@epita.fr", photo: membre2 },
  { firstName: "Gabriel", lastName: "Cantat", role: "Rôle", email: "gabriel.cantat@epita.fr", photo: membre3 },
  { firstName: "Tibo", lastName: "Hourriez", role: "Rôle", email: "tibo.hourriez@epita.fr", photo: membre4 },
  { firstName: "Eden", lastName: "Laloum", role: "Communication, Website", email: "eden.laloum@epita.fr", photo: membre5 },
];

export default function Members() {
  return (
    <SiteLayout>
      <section className="container-paper pt-20 pb-12">
        <p className="mono-label mb-6">Team Litchi</p>
        <h1 className="text-3xl sm:text-5xl text-3d leading-[1.05] max-w-3xl">THE TEAM</h1>
        <p className="mt-6 text-lg text-brand-soft">
          We are <span className="font-semibold">Team Litchi</span> — the studio behind Onigiri.
        </p>
      </section>

      {/* Members grid FIRST */}
      <section className="container-paper py-16 rule-top border-t border-border">
        <p className="mono-label mb-10">Members</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
          {members.map((m) => (
            <a
              key={m.email}
              href={`mailto:${m.email}`}
              className="group bg-background p-6 flex flex-col gap-4 hover:bg-secondary transition-colors"
            >
              <div className="aspect-[3/4] w-full overflow-hidden border border-border rounded-lg bg-secondary">
                <img
                  src={m.photo}
                  alt={`${m.firstName} ${m.lastName}`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div>
                <p className="mono-label">{m.role}</p>
                <h3 className="mt-2 text-xl font-semibold">
                  {m.firstName} {m.lastName}
                </h3>
                <p className="mt-3 text-sm text-muted-foreground group-hover:text-foreground transition">
                  {m.email} →
                </p>
              </div>
            </a>
          ))}
        </div>
        <p className="mt-6 text-xs text-muted-foreground">
          Tip: click a card to send an email directly.
        </p>
      </section>

      {/* Our Mission AFTER the photos */}
      <section className="container-paper py-20 rule-top border-t border-border grid md:grid-cols-12 gap-10">
        <div className="md:col-span-4">
          <p className="mono-label">Our mission</p>
          <h2 className="mt-3 text-3xl font-semibold">Social Connection &amp; Stimulation</h2>
        </div>
        <div className="md:col-span-8 space-y-5 text-lg leading-relaxed text-muted-foreground">
          <p>
            Our mission is to create games that act as catalysts for{" "}
            <span className="text-foreground font-semibold">social connection</span>.
          </p>
          <p>
            Through the multiplayer features of Onigiri, we aim to reconnect players via shared
            challenges.
          </p>
          <p>
            Our goal is to provide <span className="text-foreground font-semibold">mental stimulation</span>{" "}
            through fast-paced gameplay and strategic decision-making — a meaningful escape into a
            world inspired by Japanese mythology.
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
