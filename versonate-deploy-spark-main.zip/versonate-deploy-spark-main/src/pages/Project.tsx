import { Link } from "react-router-dom";
import { SiteLayout } from "@/components/SiteLayout";
import { ImageSlot } from "@/components/ImageSlot";

export default function Project() {
  return (
    <SiteLayout>
      <section className="container-paper pt-20 pb-16 grid md:grid-cols-12 gap-10 items-center">
        <div className="md:col-span-7">
          <h1 className="text-3xl sm:text-5xl text-3d leading-[1.05] max-w-4xl">ONIGIRI</h1>
          <p className="mt-6 text-lg sm:text-xl text-brand-soft max-w-xl">
            A journey between tradition and combat.
          </p>
          <p className="mt-8 max-w-2xl text-lg text-muted-foreground leading-relaxed">
            Onigiri is a video game developed as our final year project. Step into a world inspired by
            Japanese folklore where every choice shapes the story.
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link
              to="/telechargements"
              className="inline-flex items-center gap-2 rounded-md bg-brand text-brand-foreground px-5 py-3 text-sm font-medium hover:opacity-90 transition"
            >
              Download the project →
            </Link>
            <Link
              to="/membres"
              className="inline-flex items-center gap-2 rounded-md border border-border px-5 py-3 text-sm font-medium hover:bg-secondary transition"
            >
              Meet the team
            </Link>
          </div>
        </div>
        <div className="md:col-span-5">
          <ImageSlot ratio="aspect-[4/5]" label="Key art / hero image" />
        </div>
      </section>

      {/* Our Story */}
      <section className="container-paper py-20 rule-top border-t border-border grid md:grid-cols-12 gap-10">
        <div className="md:col-span-4">
          <p className="mono-label">About</p>
          <h2 className="mt-3 text-3xl font-semibold">Our Story</h2>
        </div>
        <div className="md:col-span-8 space-y-6 text-lg leading-relaxed">
          <p>
            Team Litchi was established as a professional-grade studio with a clear vision: merging
            traditional cultural motifs with modern gameplay mechanics.
          </p>
          <p className="text-muted-foreground">
            Our studio operates on the principle that technical excellence should serve the narrative.
          </p>
          <p className="text-muted-foreground">
            For Onigiri, we structured our "company" to simulate a professional environment — clearly
            defined roles, a rigorous development cycle, one goal: a polished, immersive experience.
          </p>
          <blockquote className="border-l-2 border-brand pl-5 italic text-brand-soft">
            "Welcome to the world of Onigiri, an immersive experience rooted in the mystical folklore
            of ancient Japan."
          </blockquote>
          <p className="text-muted-foreground">
            Our project was born from a desire to blend traditional aesthetics with modern gameplay.
            In a world where spirits — the Yokai — roam the shadows, players must navigate a
            landscape that challenges both their reflexes and their intellect.
          </p>
          <p className="text-muted-foreground">
            Beyond simple entertainment, our game addresses a fundamental need: social connection. By
            creating a stimulating environment, we aim to reconnect players through shared challenges
            and a deep, narrative-driven atmosphere.
          </p>
          <p>
            We truly hope this project captures your imagination as much as it has captured ours.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="rule-top border-t border-border">
        <div className="container-paper grid grid-cols-1 md:grid-cols-3 divide-x divide-border">
          {[
            { k: "5", l: "team members" },
            { k: "3", l: "playable levels" },
            { k: "1", l: "original universe" },
          ].map((s) => (
            <div key={s.l} className="py-10 px-4 first:pl-0">
              <div className="font-display text-4xl font-semibold">{s.k}</div>
              <div className="mt-2 mono-label">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Pillars */}
      <section className="container-paper py-16 rule-top border-t border-border">
        <p className="mono-label">Project pillars</p>
        <div className="mt-10 grid md:grid-cols-3 gap-px bg-border">
          {[
            { t: "Art direction", d: "Mystical Japan — ink, shadows, blood-red accents and folklore." },
            { t: "Branching story", d: "A narrative where every interaction shapes the ending." },
            { t: "Tactical combat", d: "A demanding turn-based system, quick to pick up." },
          ].map((p) => (
            <div key={p.t} className="bg-background p-8">
              <h3 className="text-xl font-semibold">{p.t}</h3>
              <p className="mt-3 text-muted-foreground">{p.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Get the game */}
      <section className="container-paper py-20 rule-top border-t border-border">
        <p className="mono-label">Get the game</p>
        <h2 className="mt-3 text-3xl font-semibold">Source code &amp; builds</h2>
        <p className="mt-4 max-w-2xl text-muted-foreground">
          Grab the source on GitHub or download a ready-to-play build directly from the site.
        </p>

        <div className="mt-10 grid md:grid-cols-2 gap-px bg-border">
          <a
            href="https://github.com/Grenixx/Onigiri---Team-Litchi.git"
            target="_blank"
            rel="noreferrer"
            className="bg-background p-8 hover:bg-secondary transition block"
          >
            <p className="mono-label">Repository</p>
            <h3 className="mt-3 text-xl font-semibold">GitHub — Full source</h3>
            <p className="mt-3 text-muted-foreground">
              Clone the official Team Litchi repository to access all sources and assets.
            </p>
            <span className="mt-5 inline-flex items-center gap-2 text-brand-soft text-sm">
              Open on GitHub →
            </span>
          </a>

          <Link
            to="/telechargements"
            className="bg-background p-8 hover:bg-secondary transition block"
          >
            <p className="mono-label">Direct download</p>
            <h3 className="mt-3 text-xl font-semibold">Playable builds</h3>
            <p className="mt-3 text-muted-foreground">
              Get the game packaged and ready to run, no setup required.
            </p>
            <span className="mt-5 inline-flex items-center gap-2 text-brand-soft text-sm">
              Go to downloads →
            </span>
          </Link>
        </div>

        <div className="mt-10 grid md:grid-cols-3 gap-px bg-border">
          {[
            {
              t: "Client",
              d: "Standalone client to join an existing server.",
              href: "/onigiri-client.zip",
            },
            {
              t: "Server",
              d: "Dedicated server to host your own session.",
              href: "/onigiri-server.zip",
            },
            {
              t: "Client + Server",
              d: "Full bundle with both, all-in-one package.",
              href: "/onigiri-client-server.zip",
            },
          ].map((b) => (
            <div key={b.t} className="bg-background p-8 flex flex-col">
              <h3 className="text-xl font-semibold">{b.t}</h3>
              <p className="mt-3 text-muted-foreground flex-1">{b.d}</p>
              <a
                href={b.href}
                download
                className="mt-6 inline-flex w-fit items-center gap-2 rounded-md bg-brand text-brand-foreground px-4 py-2 text-sm font-medium hover:opacity-90 transition"
              >
                Download ↓
              </a>
            </div>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
