import { SiteLayout } from "@/components/SiteLayout";

type Resource = { name: string; url: string; description: string };
type Category = { title: string; items: Resource[] };

const categories: Category[] = [
  {
    title: "Engine & tools",
    items: [
      { name: "Pygame", url: "https://www.pygame.org", description: "Python library used to build the game." },
    ],
  },
  {
    title: "Sound & music",
    items: [
      {
        name: "Onigiri — Sound reference (YouTube)",
        url: "https://youtu.be/HT4QLGKrpzo",
        description: "Reference video used for the sound design of Onigiri.",
      },
    ],
  },
  {
    title: "Graphics & assets",
    items: [
      {
        name: "Tiny Pixel Japan Samurai Character Pack",
        url: "https://lyniadesign.itch.io/tiny-pixel-japan-samurai-character-pack",
        description: "Sprite pack used for character art.",
      },
      { name: "Itch.io Assets", url: "https://itch.io/game-assets", description: "Royalty-free art packs." },
      { name: "Kenney.nl", url: "https://kenney.nl", description: "Free 2D / 3D assets." },
    ],
  },
];

export default function Resources() {
  return (
    <SiteLayout>
      <section className="container-paper pt-20 pb-12">
        <p className="mono-label mb-6">External resources</p>
        <h1 className="text-3xl sm:text-5xl text-3d leading-[1.05] max-w-3xl">RESOURCES</h1>
        <p className="mt-8 max-w-2xl text-lg text-muted-foreground">
          Links to the tools, assets and references that shaped the project.
        </p>
      </section>

      <section className="container-paper py-12 space-y-16">
        {categories.map((cat) => (
          <div key={cat.title} className="rule-top border-t border-border pt-10 grid md:grid-cols-12 gap-8">
            <h2 className="md:col-span-3 text-2xl font-semibold">{cat.title}</h2>
            <div className="md:col-span-9 divide-y divide-border">
              {cat.items.map((r) => (
                <a
                  key={r.url}
                  href={r.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-start justify-between gap-6 py-5 hover:bg-secondary/60 -mx-3 px-3 rounded-md transition-colors"
                >
                  <div>
                    <h3 className="font-display text-lg font-semibold">{r.name}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{r.description}</p>
                  </div>
                  <span className="mono-label shrink-0 mt-1 group-hover:text-foreground transition">
                    Visit ↗
                  </span>
                </a>
              ))}
            </div>
          </div>
        ))}
      </section>
    </SiteLayout>
  );
}
