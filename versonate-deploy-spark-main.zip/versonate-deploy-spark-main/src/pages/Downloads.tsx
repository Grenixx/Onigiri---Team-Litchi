import { SiteLayout } from "@/components/SiteLayout";

type Download = {
  title: string;
  description: string;
  size: string;
  format: string;
  href: string;
};

const downloads: Download[] = [
  {
    title: "Defence report",
    description: "Full document covering the project, the process and the results.",
    size: "~ 4 MB",
    format: "PDF",
    href: "/defence-report.pdf",
  },
  {
    title: "Source code & full project (GitHub)",
    description:
      "Official GitHub repository — full source code and project files for Onigiri by Team Litchi.",
    size: "GitHub",
    format: "GIT",
    href: "https://github.com/Grenixx/Onigiri---Team-Litchi.git",
  },
  {
    title: "Onigiri — Client",
    description: "Standalone client build to join an existing server.",
    size: "TBD",
    format: "EXE",
    href: "/onigiri-client.zip",
  },
  {
    title: "Onigiri — Server",
    description: "Dedicated server build to host your own game session.",
    size: "TBD",
    format: "EXE",
    href: "/onigiri-server.zip",
  },
  {
    title: "Onigiri — Client + Server",
    description: "Full bundle with both client and server in one package.",
    size: "TBD",
    format: "EXE",
    href: "/onigiri-client-server.zip",
  },
];

export default function Downloads() {
  return (
    <SiteLayout>
      <section className="container-paper pt-20 pb-12">
        <p className="mono-label mb-6">Files to download</p>
        <h1 className="text-3xl sm:text-5xl text-3d leading-[1.05] max-w-3xl">DOWNLOADS</h1>
        <p className="mt-8 max-w-2xl text-lg text-muted-foreground">
          All Onigiri deliverables are available below.
        </p>
      </section>

      <section className="container-paper py-12 rule-top border-t border-border">
        <div className="divide-y divide-border">
          {downloads.map((d) => (
            <div key={d.title} className="py-8 grid md:grid-cols-12 gap-6 items-center">
              <div className="md:col-span-2">
                <div className="inline-flex items-center justify-center w-16 h-20 border border-border rounded-md bg-card font-display font-semibold text-sm">
                  {d.format}
                </div>
              </div>
              <div className="md:col-span-7">
                <h2 className="text-2xl font-semibold">{d.title}</h2>
                <p className="text-muted-foreground mt-2">{d.description}</p>
                <p className="mono-label mt-3">
                  {d.format} · {d.size}
                </p>
              </div>
              <div className="md:col-span-3 md:text-right">
                <a
                  href={d.href}
                  download
                  className="inline-flex items-center gap-2 rounded-md bg-brand text-brand-foreground px-5 py-3 text-sm font-medium hover:opacity-90 transition"
                >
                  Download ↓
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 rounded-xl border border-dashed border-border p-6 text-sm text-muted-foreground">
          <p>
            <span className="mono-label mr-2">Note</span>
            Put your files in the <code className="px-1.5 py-0.5 bg-secondary rounded">public/</code>{" "}
            folder at the project root, then update the links in{" "}
            <code className="px-1.5 py-0.5 bg-secondary rounded">src/pages/Downloads.tsx</code>.
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
