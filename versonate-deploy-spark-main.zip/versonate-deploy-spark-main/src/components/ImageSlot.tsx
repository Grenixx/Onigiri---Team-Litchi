type Props = {
  src?: string;
  alt?: string;
  label?: string;
  className?: string;
  ratio?: string;
};

export function ImageSlot({
  src,
  alt = "",
  label = "Drop image here",
  className = "",
  ratio = "aspect-square",
}: Props) {
  return (
    <div className={`image-slot ${ratio} ${className}`}>
      {src ? <img src={src} alt={alt} /> : <span>{label}</span>}
    </div>
  );
}
