const PETALS = Array.from({ length: 28 });

export function FallingPetals() {
  return (
    <div className="petals-layer" aria-hidden>
      {PETALS.map((_, i) => {
        const left = Math.random() * 100;
        const duration = 8 + Math.random() * 10;
        const delay = -Math.random() * duration;
        const size = 8 + Math.random() * 12;
        const sway = (Math.random() * 60 - 30).toFixed(0);
        return (
          <span
            key={i}
            className="petal"
            style={{
              left: `${left}%`,
              width: `${size}px`,
              height: `${size}px`,
              animationDuration: `${duration}s`,
              animationDelay: `${delay}s`,
              ["--sway" as never]: `${sway}px`,
            }}
          />
        );
      })}
    </div>
  );
}
