import { Link, useLocation } from "react-router-dom";
import type { ReactNode } from "react";
import logo from "@/assets/onigiri-logo.png";

const nav = [
  { to: "/", label: "Project" },
  { to: "/membres", label: "Team" },
  { to: "/ressources", label: "Resources" },
  { to: "/telechargements", label: "Downloads" },
] as const;

export function SiteLayout({ children }: { children: ReactNode }) {
  const { pathname } = useLocation();
  return (
    <div className="min-h-screen flex flex-col">
      <header className="rule-top border-b border-border bg-background/80 backdrop-blur sticky top-0 z-50">
        <div className="container-paper flex items-center justify-between py-5">
          <Link to="/" className="flex items-center gap-3">
            <img
              src={logo}
              alt="Logo Onigiri"
              width={44}
              height={44}
              className="h-11 w-11 object-contain logo-blend"
            />
            <div className="flex flex-col leading-none gap-1">
              <span
                className="text-sm sm:text-base text-brand"
                style={{
                  fontFamily: "var(--font-brand)",
                  letterSpacing: "0.12em",
                  textShadow: "2px 2px 0 #8a1f1f, 4px 4px 0 rgba(0,0,0,0.5)",
                }}
              >
                ONIGIRI
              </span>
              <span
                className="text-[0.55rem] tracking-[0.25em] uppercase text-brand-soft/80"
                style={{ fontFamily: "var(--font-brand)" }}
              >
                Team Litchi
              </span>
            </div>
          </Link>
          <nav className="flex items-center gap-1 sm:gap-2 flex-wrap justify-end">
            {nav.map((item) => {
              const active =
                item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`px-3 py-1.5 text-sm rounded-md transition-colors ${
                    active
                      ? "bg-brand text-brand-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="rule-top mt-24 border-t border-border">
        <div className="container-paper py-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-sm text-muted-foreground">
          <p className="mono-label">© {new Date().getFullYear()} — Team Litchi</p>
          <p>All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
